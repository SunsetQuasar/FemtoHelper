local FemtoHelperCinematicTextTrigger = {}
FemtoHelperCinematicTextTrigger.name = "FemtoHelper/CinematicTextTrigger"
FemtoHelperCinematicTextTrigger.placements = {
    name = "default",
    data = {
        activationTag = "tag",
    }
}

return FemtoHelperCinematicTextTrigger