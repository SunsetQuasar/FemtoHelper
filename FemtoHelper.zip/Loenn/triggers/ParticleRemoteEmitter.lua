local ParticleRemoteEmit = {}
ParticleRemoteEmit.name = "FemtoHelper/ParticleRemoteEmit"
ParticleRemoteEmit.placements = {
    name = "default",
    data = {
        tag = "tag",
    }
}

return ParticleRemoteEmit