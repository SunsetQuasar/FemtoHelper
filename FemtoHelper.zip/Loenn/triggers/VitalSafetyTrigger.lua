local FemtohelperVitalSafetyTrigger = {}
FemtohelperVitalSafetyTrigger.name = "FemtoHelper/VitalSafetyTrigger"
FemtohelperVitalSafetyTrigger.placements = {
    name = "default",
    data = {
    }
}

return FemtohelperVitalSafetyTrigger