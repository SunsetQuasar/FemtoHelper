local FemtoHelperNoSquishController = {}

FemtoHelperNoSquishController.name = "FemtoHelper/AssistHazardController"
FemtoHelperNoSquishController.depth = 0
FemtoHelperNoSquishController.texture = "loenn/FemtoHelper/squishcontroller"
FemtoHelperNoSquishController.placements = {
    name = "controller"
}
return FemtoHelperNoSquishController
